function login(){
    var username = document.getElementById("uname").value;
    var password = document.getElementById("passwd").value;

    if(username == "admin" && password == "1234" ){
	    location.href = "../home.html";
     } else {
		alert("Username atau password atau password salah!");
        location.href = "index.html"
	}
    
}
